#TinyServer
This is a multi-thread server which is the component of my project.  
 
+ February 24 2017 v1.34   
 1. Fix bugs 
+ February 4 2017 v1.33   
 1. Fix bugs 
 2. Add coordinate transitor
+ February 4 2017 v1.32   
 1. Fix bugs:(mass data read failed, port broadcast failed)
+ February 2 2017 v1.31   
 1. Fix bugs: (In previous versions some threads are never destroyed once being created).
+ February 2 2017 v1.30     
 1.  Fix bugs.    
 2.  Use custom keys rather than socket disciptors as the keys of the map which manages sockets. 
 3.  Add coordinate transitor.    

Philip 
