## TinyPlatform
TinyPlatform is an WPF application, which is the component of my project.  
   
+  February 24 2017 version 1.1   
   Platform finished

Philip
